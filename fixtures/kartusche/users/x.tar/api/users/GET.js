w.header().set("content-type","application/json")
w.write(JSON.stringify([]))